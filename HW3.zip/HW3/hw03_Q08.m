clear all;
clc;
x=[0.9, 1.3, 1.9, 2.1, 2.6, 3, 3.9, 4.4, 4.7, 5, 6, 7, 8, 9.2, 10.5, 11.3, 11.6, 12, 12.6];
a=[1.3,1.5, 1.85, 2.1, 2.6, 2.7, 2.4, 2.15, 2.05, 2.1, 2.25, 2.3, 2.25, 1.95, 1.4, 0.9, 0.7, 0.6, 0.5];
if(length(x)~=length(a))
    fprintf('x~=a');
else
    n=length(x);
    for i=1:n-1
      h(i)=x(i+1)-x(i);
    end
    for i=2:n-1
        alf(i)=(3/h(i))*(a(i+1)-a(i))-((3/h(i-1))*(a(i)-a(i-1)));
    end
    l=0;
    m=0;
    z=0;
    for i=2:n-1
     l(i)=2*(x(i+1)-x(i-1))-h(i-1)*m(i-1);
     m(i)=h(i)/l(i);
      z(i)=(alf(i)-(h(i-1)*z(i-1)))/l(i);
    end
    l(n)=1;
    z(n)=0;
    c(n)=0;
    j=n-1;
    while(j>1||j==1)
        c(j)=z(j)-m(j)*c(j+1);
        b(j)=(a(j+1)-a(j))/h(j)-h(j)*(c(j+1)+2*c(j))/3;
        d(j)=(c(j+1)-c(j))/(3*h(j));
        j=j-1;
    end
    for i=1:n-1
       fprintf('s%d(x) = %.3f + %.3f(x-%.3f) + %3.f(x-%.3f)^2 + %.3f(x-%.3f)^3 } x elemanidir [%.1f,%.1f]\n',i-1,a(i), b(i),x(i) ,c(i),x(i), d(i),x(i),x(i),x(i+1));
    end
end
    