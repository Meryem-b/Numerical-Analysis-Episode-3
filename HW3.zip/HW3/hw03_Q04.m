%HW03_Q04_TABLO_G14
clear all;
clc;
x=[0:0.2:3];
y=cosd(x);
for i=1:16
    fprintf('cos%.2f = %.4f\n',x(i),y(i));
end